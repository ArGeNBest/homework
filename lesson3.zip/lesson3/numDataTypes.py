# Problem 1
a = 17925
b = 34**2
c = 26*3
d = 17*33
f = 4394*4

if a>=b and a>=c and a>=d and a>=f:
    print("a больше")
else:
   print("Есть число которое больше a")


# Problem 2
if a>b and a<c:
    print('Da')

print(7%3*4.8)
print(4*3 == 6*2)
print(5*5 == 5*4)


# Problem 3
a = 5
b = 6
print(a+b)

a *= 7
b *= 8
print(a, b)
print(a**2, b**2)
print(a**2 + b**2 - 193432)
# Problem 11
c = 4
d = 12
e = 25
print(a-e**(b/d)%c)


# Problem 4
a = 17*3
b = 12*5
c = 12**3
d = 13*7
f = 4**5
e = 512+512
if a > b and a > c and a> d and a>f and a>e:
    print("a больше")
elif b > a and b >c and b>d and b>f and b>e:
   print("b bolshe")
elif c > a and c> b and c>d and c>f and c>e:
   print("c bolshe")
elif d> a and d>b and d>c and d>f and d>e:
   print("d bolshe")
elif f>a and f>b and f> c and f>d and f>e:
   print("f bolshe")
else:
   print("e bolshe")


# Problem 5
print(-21 // 10) 
# -3 - потому что чистое делени равно -2,1, округление к меньшую сторону равно -3
 

# Problem 6
a = 21
b = 100
print(a/b*100, "%")


# Problem 7
year1 = 2000
year2 = 2020
age = year2- year1
print(age + 2)
print(age - 2)


# Problem 8
print((25+75+10+95)/4)


# Problem 9
a1 = 2.3
a2 = 2.7
a3 = 2.6
print((a1+a2) * a3)


# Problem 10 
a = 22 # Четное
b = 7  # От 5 до 15
c = 4.5 # Дробное
d = 7 # Нечетное
e = 135 # Любое



