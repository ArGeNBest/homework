love = "Верю"
loved = "Есть"
natue = "Горы"
reli = "Ислам"
planets = 9
dog = "net"
PI = 3.14
auto = "Mercedes"
pets = "НЕТУ"
height = 170
weight = 55
bins= "0 and 1"
active = True
opened = False
hugeplanet = "Юпитер"
sun = "Солнце"
shape = "Треугольник"
shape = "Круг"
shape = "Четыреугольник"
shape = "Многоугольник"
hair = "Брюнет"
eyes = "Черные"
derma = " Белая"
letter = "abcdejklmnopras"
symvols = '!;:@#$%^&*"/><>@'
nembers = "0123456789"








