# problem 1
tuple1 = ((5,3.26,True),("python", "argen"),"abdimajitov", False, [range(1,5)])
# problem 2
print(f"{tuple1[1][1].title()} {tuple1[2].title()}")


# Problem 3
kortej1 = (1, 2, ("q", ("w", "e"), 0), 3, (4, ("r", (7, ('x1') , 'y'), 't', 8), 5, 6))
print(kortej1[4][1][1][1])

