model="Toshiba Satellite C50-A245"
cpu="intel celeron b960"
ram= "2gb"
print("Модель: ", model,"\nПроцессор: ",cpu,"\nОперативная память: ",ram)

