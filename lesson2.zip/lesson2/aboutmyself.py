name = "Арген"
surname="Абдимажитов"
age=21
study="КНУ им. Ж.Баласагына"
course=3
direction="Математика и информатика"
before="Да, немного знаю."
wage=50000
print("Имя: ", name)
print("Фамилия: ", surname)
print("Возраст: ", age)
print("Место учебы: ", study)
print("Курс: ", course)
print("Направления: ", direction)
print("Раньше изучали программироване?: ", before)
print(f"{wage} и выше")
