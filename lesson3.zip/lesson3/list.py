# Problem 1
list1 = [1, 5.63, True, "Jack", (4, 5)]
print(list1.count("Jack")) # problem 2
del list1[1::2] # problem 3
print(list1)


# Problem 4
about = ["Argen", 2000, "Python"]
print(about)


# Problem 5
names = ["albina", "nurgul", "adilet", "argen", "nurgazy"]
print(" ".join(names).title())


